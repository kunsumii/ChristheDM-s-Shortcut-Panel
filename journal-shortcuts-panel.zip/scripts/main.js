
const MODULE_ID = "journal-shortcuts-panel";
const SETTING_SHORTCUTS = "shortcuts";     // world
const SETTING_ACTIVE_TYPE = "activeType"; // client
const SETTING_ACTIVE_CATS = "activeCats"; // client (per-type category selection)
const SETTING_PANEL_VISIBLE = "panelVisible"; // client

const TYPES = ["journals", "actors", "items", "rolltables", "macros"];
const TYPE_META = {
  journals:   { label: "Journals",   icon: "fa-book-open", dropHint: "Journal Entry or Page" },
  actors:     { label: "Actors",     icon: "fa-user",      dropHint: "Actor" },
  items:      { label: "Items",      icon: "fa-sack",      dropHint: "Item" },
  rolltables: { label: "Rolltables", icon: "fa-dice-d20",  dropHint: "RollTable" },
  macros:     { label: "Macros",     icon: "fa-terminal",  dropHint: "Macro" }
};

const DRAG_TYPE_ENTRY_REORDER = "application/x-jsp-reorder";
const DRAG_TYPE_CATEGORY_REORDER = "application/x-jsp-category-reorder";

function deepClone(obj) {
  return foundry.utils.deepClone(obj);
}

function normalizeShortcutArray(raw) {
  if (!raw) return [];
  if (Array.isArray(raw)) {
    return raw.map(s => ({ label: s?.label ?? "", uuid: s?.uuid ?? "" }));
  }
  if (typeof raw === "object") {
    // expandedObject format: {0:{...},1:{...}}
    const keys = Object.keys(raw);
    const isNumericMap = keys.every(k => Number.isFinite(Number(k)));
    if (isNumericMap) {
      return keys
        .map(k => [Number(k), raw[k]])
        .sort((a, b) => a[0] - b[0])
        .map(([, v]) => ({ label: v?.label ?? "", uuid: v?.uuid ?? "" }));
    }
  }
  return [];
}

function normalizeShortcutsByType(raw) {
  // v1.2.0 and earlier stored an array of journal shortcuts
  if (Array.isArray(raw)) {
    return {
      journals: normalizeShortcutArray(raw),
      actors: [],
      items: [],
      rolltables: [],
      macros: []
    };
  }

  // expanded numeric map (old form submissions)
  if (raw && typeof raw === "object" && !TYPES.some(t => t in raw)) {
    // If it looks like numeric keys, treat as journals
    const keys = Object.keys(raw);
    const isNumericMap = keys.length && keys.every(k => Number.isFinite(Number(k)));
    if (isNumericMap) {
      return {
        journals: normalizeShortcutArray(raw),
        actors: [],
        items: [],
        rolltables: [],
        macros: []
      };
    }
  }

  const out = {};
  for (const t of TYPES) out[t] = normalizeShortcutArray(raw?.[t]);
  return out;
}



/* -------------------------------------------- */
/* vNext Data Model (Categories / Visibility / Icons) */
/* -------------------------------------------- */

const DATA_VERSION = 4;
const CATEGORY_BROWSE = "__browse__";
const CATEGORY_ALL = "__all__";
// Entries may have categoryId = "" (uncategorized). Uncategorized entries appear only under "All".

function isImageIcon(value) {
  if (!value) return false;
  const v = String(value).trim();
  if (!v) return false;
  // Heuristic: treat common image paths / urls as image icons
  return (
    v.startsWith("data:") ||
    v.startsWith("http://") ||
    v.startsWith("https://") ||
    v.includes("/") ||
    /\.(png|jpg|jpeg|webp|svg)$/i.test(v)
  );
}

function cleanIcon(value) {
  if (value == null) return "";
  let v = String(value).trim();
  if (!v) return "";
  // If user entered "fas fa-book-open" keep just "fa-book-open" for storage.
  v = v.replace(/\b(fas|far|fal|fab|fa-solid|fa-regular|fa-light|fa-brands)\b/g, "").trim();
  v = v.replace(/\s+/g, " ");
  // If it looks like "fa-book-open" or "fa-book-open something", keep first fa-* token
  const fa = v.split(" ").find(t => t.startsWith("fa-"));
  if (!isImageIcon(v) && fa) return fa;
  return v;
}

function dividerColorToRgbTriplet(color) {
  const fallback = "168 85 247"; // matches --jsp-purple
  if (!color) return fallback;
  const c = String(color).trim();
  // #rgb or #rrggbb
  const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(c);
  if (m) {
    let hex = m[1];
    if (hex.length === 3) hex = hex.split("").map(ch => ch + ch).join("");
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    if ([r, g, b].every(n => Number.isFinite(n))) return `${r} ${g} ${b}`;
  }
  return fallback;
}

function coerceBool(value, fallback = true) {
  if (value === true || value === false) return value;
  if (value == null || value === "") return fallback;
  const v = String(value).toLowerCase().trim();
  if (["1", "true", "yes", "on"].includes(v)) return true;
  if (["0", "false", "no", "off"].includes(v)) return false;
  return fallback;
}

function toIndexArray(raw) {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === "object") {
    const keys = Object.keys(raw);
    const isNumericMap = keys.every(k => Number.isFinite(Number(k)));
    if (isNumericMap) {
      return keys
        .map(k => [Number(k), raw[k]])
        .sort((a, b) => a[0] - b[0])
        .map(([, v]) => v);
    }
  }
  return [];
}

function defaultShortcutsData() {
  const tabs = {};
  for (const t of TYPES) {
    tabs[t] = {
      icon: TYPE_META[t]?.icon ?? "fa-link",
      categories: [],
      entries: []
    };
  }
  return { version: DATA_VERSION, tabs };
}

function normalizeCategoryImageScale(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 1;
  return Math.max(1, Math.min(4, n));
}

function normalizeCategoryOffset(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(-400, Math.min(400, Math.round(n)));
}

function normalizeCategories(rawCats) {
  const arr = toIndexArray(rawCats);
  let cats = arr
    .map(c => ({
      id: String(c?.id ?? "").trim(),
      name: String(c?.name ?? "").trim(),
      icon: cleanIcon(c?.icon ?? ""),
      image: String(c?.image ?? "").trim(),
      imageOffsetX: normalizeCategoryOffset(c?.imageOffsetX),
      imageOffsetY: normalizeCategoryOffset(c?.imageOffsetY),
      imageScale: normalizeCategoryImageScale(c?.imageScale)
    }))
    .filter(c => c.id && c.name);

  // Drop legacy "Default" category (removed in v1.5.3+)
  cats = cats.filter(c => c.id !== "default" && c.name.toLowerCase() !== "default");

  // Deduplicate IDs (keep first)
  const seen = new Set();
  cats = cats.filter(c => {
    if (seen.has(c.id)) return false;
    seen.add(c.id);
    return true;
  });

  return cats;
}

function normalizeEntries(rawEntries, categories) {
  const arr = toIndexArray(rawEntries);
  const validCatIds = new Set((categories ?? []).map(c => c.id));

  return arr.map(e => {
    let categoryId = String(e?.categoryId ?? "").trim();
    // Legacy default category -> uncategorized
    if (categoryId === "default" || categoryId.toLowerCase() === "default") categoryId = "";
    if (categoryId && !validCatIds.has(categoryId)) categoryId = "";
    return {
      label: String(e?.label ?? "").trim(),
      uuid: String(e?.uuid ?? "").trim(),
      icon: cleanIcon(e?.icon ?? ""),
      visibleToPlayers: coerceBool(e?.visibleToPlayers, true),
      categoryId,
      entryType: (String(e?.entryType ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut",
      dividerColor: String(e?.dividerColor ?? "").trim()
    };
  });
}

function normalizeShortcutsData(raw) {
  // v2+ data model (tabs object)
  if (raw && typeof raw === "object" && raw.tabs && typeof raw.tabs === "object") {
    const base = defaultShortcutsData();
    const out = { version: DATA_VERSION, tabs: {} };
    for (const t of TYPES) {
      const tabRaw = raw.tabs?.[t] ?? {};
      const icon = cleanIcon(tabRaw?.icon ?? base.tabs[t].icon) || base.tabs[t].icon;
      const categories = normalizeCategories(tabRaw?.categories);
      const entries = normalizeEntries(tabRaw?.entries, categories);
      out.tabs[t] = { icon, categories, entries };
    }
    return out;
  }

  // Legacy formats (arrays / byType maps)
  const byType = normalizeShortcutsByType(raw);
  const out = defaultShortcutsData();
  for (const t of TYPES) {
    out.tabs[t].entries = (byType[t] ?? []).map(s => ({
      label: String(s?.label ?? "").trim(),
      uuid: String(s?.uuid ?? "").trim(),
      icon: "",
      visibleToPlayers: true,
      categoryId: "",
      entryType: "shortcut",
      dividerColor: ""
    }));
  }
  return out;
}
async function resolveName(uuid) {
  if (!uuid) return "";
  try {
    const doc = await fromUuid(uuid);
    if (!doc) return "";
    if (doc?.documentName === "JournalEntryPage") {
      const entryName = doc.parent?.name ?? "Journal";
      return `${entryName} / ${doc.name}`;
    }
    return doc?.name ?? "";
  } catch {
    return "";
  }
}

async function openJournalByUuid(uuid) {
  if (!uuid) return;
  const doc = await fromUuid(uuid);
  if (!doc) return ui.notifications?.warn("That Journal Entry/Page no longer exists.");

  if (doc.documentName === "JournalEntryPage") {
    const entry = doc.parent;
    if (!entry) return ui.notifications?.warn("That Journal Page no longer has a parent Journal.");
    try {
      entry.sheet?.render(true, { pageId: doc.id });
      return;
    } catch {
      entry.sheet?.render(true);
      try { entry.sheet?.goToPage?.(doc.id); } catch (_) {}
      return;
    }
  }

  if (doc.documentName === "JournalEntry") {
    doc.sheet?.render(true);
    return;
  }

  ui.notifications?.warn("Selected document is not a Journal Entry or Page.");
}

async function openByType(type, uuid) {
  if (!uuid) return;
  try {
    if (type === "journals") return openJournalByUuid(uuid);

    const doc = await fromUuid(uuid);
    if (!doc) return ui.notifications?.warn("That shortcut target no longer exists.");

    if (type === "macros") {
      // Macro execution respects Foundry permissions.
      try {
        doc.execute?.();
      } catch (e) {
        console.error(e);
        ui.notifications?.warn("Could not execute that Macro.");
      }
      return;
    }

    // Actors / Items / Rolltables
    if (doc.sheet?.render) {
      doc.sheet.render(true);
      return;
    }

    ui.notifications?.warn("That shortcut cannot be opened as a sheet.");
  } catch (e) {
    console.error(e);
    ui.notifications?.warn("Could not open that shortcut.");
  }
}


function readFoundryDragData(ev) {
  const oe = ev?.originalEvent ?? ev;
  try {
    return TextEditor.getDragEventData(oe);
  } catch (_) {
    try {
      const raw = oe?.dataTransfer?.getData("text/plain");
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }
}

function acceptedDocTypesForTab(tabKey) {
  switch (tabKey) {
    case "journals": return new Set(["JournalEntry", "JournalEntryPage"]);
    case "actors": return new Set(["Actor"]);
    case "items": return new Set(["Item"]);
    case "rolltables": return new Set(["RollTable"]);
    case "macros": return new Set(["Macro"]);
    default: return new Set();
  }
}

function extractUuidFromDragData(data) {
  if (!data) return null;
  if (data.uuid) return String(data.uuid);

  if (data.pack && data.id) return `Compendium.${data.pack}.${data.id}`;

  if (data.type && data.id) {
    if (data.type === "JournalEntryPage" && data.parentId) {
      return `JournalEntry.${data.parentId}.JournalEntryPage.${data.id}`;
    }
    return `${data.type}.${data.id}`;
  }
  return null;
}

function createCanvasDragDataForTab(tabKey, uuid) {
  if (!uuid) return null;
  if (tabKey === "actors") return { type: "Actor", uuid, jspSource: MODULE_ID };
  if (tabKey === "items") return { type: "Item", uuid, jspSource: MODULE_ID, jspCreateTile: true };
  return null;
}



/* -------------------------------------------- */
/* Small Dialog Helpers */
/* -------------------------------------------- */

function _escapeForInput(value) {
  return foundry.utils.escapeHTML(String(value ?? "")).replace(/"/g, "&quot;");
}

async function promptText({ title, label, initial = "" }) {
  return new Promise((resolve) => {
    let resolved = false;
    const dlg = new Dialog({
      title,
      content: `
        <form class="jsp-prompt">
          <div class="form-group">
            <label>${_escapeForInput(label)}</label>
            <input type="text" name="value" value="${_escapeForInput(initial)}" autofocus />
          </div>
        </form>
      `,
      buttons: {
        ok: {
          label: "OK",
          callback: (html) => {
            resolved = true;
            const v = html.find("input[name='value']").val();
            resolve(String(v ?? "").trim());
          }
        },
        cancel: {
          label: "Cancel",
          callback: () => {
            resolved = true;
            resolve(null);
          }
        }
      },
      default: "ok",
      close: () => {
        if (!resolved) resolve(null);
      }
    });
    dlg.render(true);
  });
}

async function promptSelect({ title, label, options = [], initial = "" }) {
  return new Promise((resolve) => {
    let resolved = false;
    const optionHTML = options.map(opt => {
      const value = String(opt?.value ?? "");
      const text = String(opt?.label ?? value);
      const selected = value === String(initial ?? "") ? ' selected' : '';
      return `<option value="${_escapeForInput(value)}"${selected}>${foundry.utils.escapeHTML(text)}</option>`;
    }).join("");

    const dlg = new Dialog({
      title,
      content: `
        <form class="jsp-prompt jsp-prompt-select">
          <div class="form-group">
            <label>${_escapeForInput(label)}</label>
            <select name="value" autofocus>${optionHTML}</select>
          </div>
        </form>
      `,
      buttons: {
        ok: {
          label: "OK",
          callback: (html) => {
            resolved = true;
            const v = html.find("select[name='value']").val();
            resolve(String(v ?? ""));
          }
        },
        cancel: {
          label: "Cancel",
          callback: () => {
            resolved = true;
            resolve(null);
          }
        }
      },
      default: "ok",
      close: () => {
        if (!resolved) resolve(null);
      }
    });
    dlg.render(true);
  });
}

async function confirmDialog({ title, content, yes = "Yes", no = "No" }) {
  return new Promise((resolve) => {
    let resolved = false;
    const dlg = new Dialog({
      title,
      content: `<div class="jsp-confirm">${content}</div>`,
      buttons: {
        yes: {
          label: yes,
          callback: () => {
            resolved = true;
            resolve(true);
          }
        },
        no: {
          label: no,
          callback: () => {
            resolved = true;
            resolve(false);
          }
        }
      },
      default: "no",
      close: () => {
        if (!resolved) resolve(false);
      }
    });
    dlg.render(true);
  });
}

function openImageFilePicker({ current = "", callback } = {}) {
  const picker = new FilePicker({
    type: "imagevideo",
    current: String(current ?? "").trim(),
    callback: async (path) => {
      if (!path) return;
      await callback?.(String(path).trim());
    }
  });

  if (typeof picker.render === "function") {
    picker.render(true);
    return picker;
  }
  if (typeof picker.browse === "function") {
    picker.browse();
    return picker;
  }
  return null;
}

function getCoverDimensions(naturalWidth, naturalHeight, boxWidth, boxHeight) {
  const nw = Number(naturalWidth) || 1;
  const nh = Number(naturalHeight) || 1;
  const bw = Number(boxWidth) || 1;
  const bh = Number(boxHeight) || 1;
  const factor = Math.max(bw / nw, bh / nh);
  return { width: nw * factor, height: nh * factor };
}

function clampCategoryImageTransform({ x = 0, y = 0, scale = 1 } = {}, naturalWidth, naturalHeight, boxWidth, boxHeight) {
  const safeScale = normalizeCategoryImageScale(scale);
  const cover = getCoverDimensions(naturalWidth, naturalHeight, boxWidth, boxHeight);
  const maxX = Math.max(0, (cover.width * safeScale - boxWidth) / 2);
  const maxY = Math.max(0, (cover.height * safeScale - boxHeight) / 2);
  return {
    x: Math.round(Math.max(-maxX, Math.min(maxX, Number(x) || 0))),
    y: Math.round(Math.max(-maxY, Math.min(maxY, Number(y) || 0))),
    scale: safeScale
  };
}

/* -------------------------------------------- */
/* Overlay Panel                                */
/* -------------------------------------------- */

class ShortcutsOverlayPanel {
  static instance;

  constructor() {
    this.visible = false;
    this._observer = null;
    this._resizeObserver = null;
    this._bodyObserver = null;
    this.activeType = game.settings.get(MODULE_ID, SETTING_ACTIVE_TYPE) || "actors";
    if (!TYPES.includes(this.activeType)) this.activeType = "actors";

    this.element = document.createElement("div");
    this.element.id = "jsp-overlay";
    this.element.classList.add("jsp-hidden");
    this.element.innerHTML = `
      <div class="jsp-panel">
        <div class="jsp-tabs" aria-label="Shortcut Types"></div>
        <div class="jsp-body" aria-label="Shortcut Body">
          <div class="jsp-cats" aria-label="Shortcut Categories"></div>
          <div class="jsp-list" aria-label="Shortcut List"></div>
        </div>
      </div>
    `;
    document.body.appendChild(this.element);

    this._tabsEl = this.element.querySelector(".jsp-tabs");
    this._gmToolsEl = null;
    this._bodyEl = this.element.querySelector(".jsp-body");
    this._catsEl = this.element.querySelector(".jsp-cats");
    this._listEl = this.element.querySelector(".jsp-list");

    this._installObservers();
    this._renderTabs();
    this._renderGMTools();
    this._renderCategories();
    this.refreshList();
  }

  toggle() {
    this.setVisible(!this.visible);
  }

  setVisible(visible) {
    this.visible = !!visible;
    this.element.classList.toggle("jsp-hidden", !this.visible);
    if (this.visible) this._position();
  }

  refreshAll() {
    this._renderTabs();
    this._renderGMTools();
    this._renderCategories();
    this.refreshList();
  }

  _renderGMTools() {
    // GM actions now live in the side category rail.
    return;
  }

  refreshList() {
  const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
  const data = normalizeShortcutsData(deepClone(raw));
  const tab = data.tabs?.[this.activeType];
  if (!tab) return;

  const activeCat = this._getActiveCategory(this.activeType, tab);

  this._listEl.classList.remove("jsp-mode-list", "jsp-mode-categories");
  this._listEl.innerHTML = "";

  if (activeCat === CATEGORY_BROWSE) {
    this._renderCategoryBrowser(tab);
    this._syncActiveTabUI();
    this._syncActiveCategoryUI(activeCat);
    this._position();
    return;
  }

  let list = (tab.entries ?? [])
    .map((s, idx) => ({
      sourceIndex: idx,
      label: String(s?.label ?? "").trim(),
      uuid: String(s?.uuid ?? "").trim(),
      icon: cleanIcon(s?.icon ?? ""),
      visibleToPlayers: coerceBool(s?.visibleToPlayers, true),
      categoryId: String(s?.categoryId ?? "").trim(),
      entryType: (String(s?.entryType ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut",
      dividerColor: String(s?.dividerColor ?? "").trim()
    }))
    .filter((s) => {
      if (!s.label) return false;
      if (s.entryType === "divider") return true;
      return !!s.uuid;
    });

  if (!game.user.isGM) list = list.filter(s => s.visibleToPlayers);

  if (activeCat !== CATEGORY_ALL) {
    list = list.filter(s => (s.categoryId || "") === activeCat);
  } else {
    const cats = tab.categories ?? [];
    const nonDiv = list.filter(s => s.entryType !== "divider");
    const grouped = [];

    for (const c of cats) {
      const group = nonDiv.filter(s => (s.categoryId || "") === c.id);
      if (!group.length) continue;
      grouped.push({
        sourceIndex: null,
        label: String(c?.name ?? "").trim() || "Category",
        uuid: "",
        icon: "",
        visibleToPlayers: true,
        categoryId: c.id,
        entryType: "divider",
        dividerColor: ""
      });
      grouped.push(...group);
    }

    const unc = nonDiv.filter(s => !(s.categoryId || ""));
    if (unc.length) {
      grouped.push({
        sourceIndex: null,
        label: "Uncategorized",
        uuid: "",
        icon: "",
        visibleToPlayers: true,
        categoryId: "",
        entryType: "divider",
        dividerColor: ""
      });
      grouped.push(...unc);
    }

    list = grouped;
  }

  const visibleIndices = list.map(s => s.sourceIndex).filter(i => Number.isFinite(i));
  const canStartDrag = !!game.user.isGM;
  const canReorder = canStartDrag && activeCat !== CATEGORY_ALL;

  this._listEl.classList.add("jsp-mode-list");
  if (this._listEl) {
    this._listEl.ondragover = (ev) => {
      if (!game.user.isGM) return;
      ev.preventDefault();
      this._listEl.classList.add("jsp-list-drop-ready");
      try { ev.dataTransfer.dropEffect = this._isInternalOverlayDrag(ev) ? "move" : "copy"; } catch (_) {}
    };
    this._listEl.ondragleave = () => {
      this._listEl.classList.remove("jsp-list-drop-ready");
    };
    this._listEl.ondrop = async (ev) => {
      if (!game.user.isGM) return;
      ev.preventDefault();
      ev.stopPropagation();
      this._listEl.classList.remove("jsp-list-drop-ready");
      if (this._isInternalOverlayDrag(ev) && canReorder) {
        const fromSrc = Number(this._dragSrcIndex);
        if (!Number.isFinite(fromSrc)) return;
        await this._reorderWithinVisibleSubset(fromSrc, null, visibleIndices);
        return;
      }
      await this._handleExternalOverlayDrop(ev, null, activeCat === CATEGORY_ALL ? undefined : activeCat);
    };
  }

  const attachDrag = (el, srcIndex, sceneDragData = null) => {
    if (!canStartDrag || !Number.isFinite(Number(srcIndex))) return;
    el.setAttribute("draggable", "true");

    el.addEventListener("dragstart", (ev) => {
      try {
        this._dragSrcIndex = srcIndex;
        this._dragActive = true;
        el.classList.add("jsp-dragging");
        ev.dataTransfer.effectAllowed = sceneDragData ? "copyMove" : "move";
        ev.dataTransfer.setData(DRAG_TYPE_ENTRY_REORDER, JSON.stringify({ srcIndex }));
        ev.dataTransfer.setData("text/plain", JSON.stringify(sceneDragData || { srcIndex }));
        if (sceneDragData) ev.dataTransfer.setData("application/json", JSON.stringify(sceneDragData));
      } catch (_) {}
    });

    el.addEventListener("dragend", () => {
      try {
        el.classList.remove("jsp-dragging");
        this._dragActive = false;
        this._dragSrcIndex = null;
        this._suppressClickUntil = Date.now() + 250;
        this._listEl?.querySelectorAll?.(".jsp-drop-target")?.forEach?.(n => n.classList.remove("jsp-drop-target"));
      } catch (_) {}
    });

    el.addEventListener("dragover", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      try { ev.dataTransfer.dropEffect = "move"; } catch (_) {}
      el.classList.add("jsp-drop-target");
    });

    el.addEventListener("dragleave", () => {
      el.classList.remove("jsp-drop-target");
    });

    el.addEventListener("drop", async (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      el.classList.remove("jsp-drop-target");

      if (this._isInternalOverlayDrag(ev)) {
        const fromSrc = Number(this._dragSrcIndex);
        const toSrc = Number(srcIndex);
        if (!Number.isFinite(fromSrc) || !Number.isFinite(toSrc)) return;
        if (fromSrc === toSrc) return;

        await this._reorderWithinVisibleSubset(fromSrc, toSrc, visibleIndices);
        return;
      }

      await this._handleExternalOverlayDrop(ev, Number.isFinite(Number(srcIndex)) ? Number(srcIndex) : null, activeCat === CATEGORY_ALL ? undefined : activeCat);
    });
  };

  if (!list.length) {
    const empty = document.createElement("div");
    empty.className = "jsp-empty-state";
    empty.innerHTML = game.user.isGM
      ? `<i class="fas fa-hand-pointer"></i><div><b>No shortcuts in this view yet.</b><br><span>Drag &amp; drop ${foundry.utils.escapeHTML(TYPE_META[this.activeType]?.dropHint ?? "documents")} here.</span></div>`
      : `<i class="fas fa-folder-open"></i><div><b>Nothing to show here yet.</b></div>`;
    this._listEl.appendChild(empty);
  }

  for (const sc of list) {
    if (sc.entryType === "divider") {
      const div = document.createElement("div");
      div.className = "jsp-divider";
      div.title = sc.label;
      div.dataset.srcIndex = String(sc.sourceIndex);

      const rgb = dividerColorToRgbTriplet(sc.dividerColor);
      div.style.setProperty("--jsp-div-rgb", rgb);
      div.innerHTML = `<div class="jsp-divider-text">${foundry.utils.escapeHTML(sc.label)}</div>`;
      attachDrag(div, sc.sourceIndex);
      if (game.user.isGM && Number.isFinite(sc.sourceIndex)) {
        div.addEventListener("contextmenu", (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          this._openEntryContextMenu(sc.sourceIndex);
        });
      }
      this._listEl.appendChild(div);
      continue;
    }

    const item = document.createElement("div");
    item.className = "jsp-item";
    item.dataset.uuid = sc.uuid;
    item.dataset.type = this.activeType;
    item.dataset.srcIndex = String(sc.sourceIndex);
    item.title = sc.label;

    const fallbackIcon = TYPE_META[this.activeType]?.icon ?? "fa-book-open";
    const iconValue = cleanIcon(sc.icon) || fallbackIcon;
    const iconHTML = isImageIcon(iconValue)
      ? `<img class="jsp-icon-img" src="${foundry.utils.escapeHTML(iconValue)}" alt="" />`
      : `<i class="fas ${foundry.utils.escapeHTML(iconValue)}"></i>`;

    item.innerHTML = `
      <div class="jsp-icon">${iconHTML}</div>
      <div class="jsp-label">${foundry.utils.escapeHTML(sc.label)}</div>
    `;

    item.addEventListener("click", (ev) => {
      if (this._dragActive) return;
      if (this._suppressClickUntil && Date.now() < this._suppressClickUntil) return;
      ev.preventDefault();
      ev.stopPropagation();
      openByType(this.activeType, sc.uuid);
    });

    attachDrag(item, sc.sourceIndex, createCanvasDragDataForTab(this.activeType, sc.uuid));
    if (game.user.isGM && Number.isFinite(sc.sourceIndex)) {
      item.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        this._openEntryContextMenu(sc.sourceIndex);
      });
    }
    this._listEl.appendChild(item);
  }

  this._syncActiveTabUI();
  this._syncActiveCategoryUI(activeCat);
  this._position();
}

  _renderCategoryBrowser(tab) {
    let cats = tab.categories ?? [];
    if (!game.user.isGM) {
      const visibleEntries = (tab.entries ?? []).filter(e => coerceBool(e?.visibleToPlayers, true));
      const allowed = new Set(visibleEntries.map(e => String(e?.categoryId ?? "").trim()).filter(Boolean));
      cats = cats.filter(c => allowed.has(c.id));
    }

    this._listEl.classList.add("jsp-mode-categories");
    this._listEl.ondragover = null;
    this._listEl.ondragleave = null;
    this._listEl.ondrop = null;

    const makeCategoryArtHTML = (cat) => {
      const iconValue = cleanIcon(cat?.icon ?? "") || "fa-folder";
      if (cat?.image) {
        return `<div class="jsp-category-art"><img src="${foundry.utils.escapeHTML(cat.image)}" alt="" style="transform: translate(${Number(cat.imageOffsetX ?? 0)}px, ${Number(cat.imageOffsetY ?? 0)}px) scale(${Number(cat.imageScale ?? 1)});" /></div>`;
      }
      return `<div class="jsp-category-art jsp-category-art-fallback">${isImageIcon(iconValue)
        ? `<img class="jsp-category-fallback-img" src="${foundry.utils.escapeHTML(iconValue)}" alt="" />`
        : `<i class="fas ${foundry.utils.escapeHTML(iconValue)}"></i>`}</div>`;
    };

    const makeTile = ({ id, name, artHTML, contextId = null, extraClass = "" }) => {
      const tile = document.createElement("button");
      tile.type = "button";
      tile.className = `jsp-category-card ${extraClass}`.trim();
      tile.dataset.cat = id;
      tile.title = name;
      tile.innerHTML = `${artHTML}<span class="jsp-category-title">${foundry.utils.escapeHTML(name)}</span>`;

      tile.addEventListener("click", async (ev) => {
        if (this._dragCategorySuppressClickUntil && Date.now() < this._dragCategorySuppressClickUntil) return;
        ev.preventDefault();
        ev.stopPropagation();
        await game.settings.set(MODULE_ID, SETTING_ACTIVE_CATS, {
          ...(game.settings.get(MODULE_ID, SETTING_ACTIVE_CATS) || {}),
          [this.activeType]: id
        });
        this.refreshAll();
      });

      if (game.user.isGM && contextId) {
        this._applyCategoryReorderHandlers(tile, contextId);
        tile.addEventListener("contextmenu", (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          this._openCategoryContextMenu(contextId);
        });
      }

      this._applyCategoryTileDropHandlers(tile, id === CATEGORY_ALL ? "" : id);
      return tile;
    };

    const allTile = makeTile({
      id: CATEGORY_ALL,
      name: "All",
      artHTML: `<div class="jsp-category-art jsp-category-art-fallback"><i class="fas fa-border-all"></i></div>`,
      extraClass: "jsp-category-card-all"
    });
    this._listEl.appendChild(allTile);

    for (const cat of cats) {
      this._listEl.appendChild(makeTile({
        id: cat.id,
        name: cat.name,
        artHTML: makeCategoryArtHTML(cat),
        contextId: cat.id
      }));
    }

    if (game.user.isGM) {
      const addTile = document.createElement("button");
      addTile.type = "button";
      addTile.className = "jsp-category-card jsp-category-card-add";
      addTile.title = "Add Category";
      addTile.innerHTML = `
        <div class="jsp-category-art jsp-category-art-fallback">
          <i class="fas fa-plus"></i>
        </div>
        <span class="jsp-category-title">Add Category</span>
      `;
      addTile.addEventListener("click", async (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        await this._promptAddCategory();
      });
      this._listEl.appendChild(addTile);
    }

    if (!cats.length && !game.user.isGM) {
      const empty = document.createElement("div");
      empty.className = "jsp-empty-state";
      empty.innerHTML = `<i class="fas fa-folder-open"></i><div><b>No categories are available here yet.</b></div>`;
      this._listEl.appendChild(empty);
    }
  }


  _applyCategoryTileDropHandlers(tile, forcedCategoryId = "") {
    if (!game.user.isGM || !tile) return;

    tile.addEventListener("dragover", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      tile.classList.add("jsp-drop-target");
      try {
        if (this._isCategoryTileDrag(ev) || this._isInternalOverlayDrag(ev)) ev.dataTransfer.dropEffect = "move";
        else ev.dataTransfer.dropEffect = "copy";
      } catch (_) {}
    });

    tile.addEventListener("dragleave", () => {
      tile.classList.remove("jsp-drop-target");
    });

    tile.addEventListener("drop", async (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      tile.classList.remove("jsp-drop-target");

      if (this._isCategoryTileDrag(ev)) {
        const fromCatId = String(this._dragCategoryId ?? "").trim();
        const toCatId = String(forcedCategoryId ?? "").trim();
        if (!fromCatId || !toCatId || fromCatId === toCatId) return;
        await this._swapCategoryPositions(fromCatId, toCatId);
        return;
      }

      if (this._isInternalOverlayDrag(ev)) {
        const fromSrc = Number(this._dragSrcIndex);
        if (!Number.isFinite(fromSrc)) return;
        await this._moveEntryToCategory(fromSrc, forcedCategoryId);
        return;
      }

      await this._handleExternalOverlayDrop(ev, null, forcedCategoryId);
    });
  }

  _applyCategoryReorderHandlers(tile, categoryId) {
    if (!game.user.isGM || !tile || !categoryId) return;
    tile.setAttribute("draggable", "true");

    tile.addEventListener("dragstart", (ev) => {
      try {
        this._dragCategoryId = String(categoryId);
        this._dragCategoryActive = true;
        tile.classList.add("jsp-dragging");
        ev.dataTransfer.effectAllowed = "move";
        ev.dataTransfer.setData(DRAG_TYPE_CATEGORY_REORDER, JSON.stringify({ categoryId }));
        ev.dataTransfer.setData("text/plain", JSON.stringify({ categoryId, type: "JSPCategory" }));
      } catch (_) {}
    });

    tile.addEventListener("dragend", () => {
      try {
        tile.classList.remove("jsp-dragging");
        this._dragCategoryActive = false;
        this._dragCategoryId = null;
        this._dragCategorySuppressClickUntil = Date.now() + 250;
        this._listEl?.querySelectorAll?.(".jsp-drop-target")?.forEach?.(n => n.classList.remove("jsp-drop-target"));
      } catch (_) {}
    });
  }

  async _swapCategoryPositions(fromCategoryId, toCategoryId) {
    if (!game.user.isGM || !fromCategoryId || !toCategoryId || fromCategoryId === toCategoryId) return;

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    const categories = toIndexArray(tab.categories);
    const fromIndex = categories.findIndex(c => c?.id === fromCategoryId);
    const toIndex = categories.findIndex(c => c?.id === toCategoryId);
    if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) return;

    const moved = categories[fromIndex];
    categories[fromIndex] = categories[toIndex];
    categories[toIndex] = moved;
    tab.categories = categories;
    data.tabs[this.activeType] = tab;

    await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    this.refreshAll();
  }



  _isInternalOverlayDrag(ev) {
    try {
      const types = Array.from((ev?.dataTransfer?.types ?? ev?.originalEvent?.dataTransfer?.types ?? []));
      return types.includes(DRAG_TYPE_ENTRY_REORDER) || !!this._dragActive;
    } catch (_) {
      return !!this._dragActive;
    }
  }

  _isCategoryTileDrag(ev) {
    try {
      const types = Array.from((ev?.dataTransfer?.types ?? ev?.originalEvent?.dataTransfer?.types ?? []));
      return types.includes(DRAG_TYPE_CATEGORY_REORDER) || !!this._dragCategoryActive;
    } catch (_) {
      return !!this._dragCategoryActive;
    }
  }

  async _handleExternalOverlayDrop(ev, targetSrcIndex = null, forcedCategoryId = undefined) {
    if (!game.user.isGM) return;

    const data = readFoundryDragData(ev);
    const uuid = extractUuidFromDragData(data);
    if (!uuid) return;

    const accepted = acceptedDocTypesForTab(this.activeType);
    const docType = data?.type ?? data?.documentName ?? data?.documentType;
    if (docType && accepted.size && !accepted.has(docType)) {
      ui.notifications?.warn(`That drop isn't a valid ${TYPE_META[this.activeType]?.dropHint ?? "document"} for this tab.`);
      return;
    }

    const label = (await resolveName(uuid)) || "Shortcut";
    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const shortcutsData = normalizeShortcutsData(deepClone(raw));
    const tab = shortcutsData.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    const activeCat = this._getActiveCategory(this.activeType, tab);
    const categoryId = forcedCategoryId !== undefined ? String(forcedCategoryId ?? "").trim() : (activeCat === CATEGORY_ALL || activeCat === CATEGORY_BROWSE ? "" : activeCat);

    const entry = {
      label,
      uuid,
      icon: "",
      visibleToPlayers: true,
      categoryId,
      entryType: "shortcut",
      dividerColor: "#a855f7"
    };

    tab.entries = toIndexArray(tab.entries);
    const insertAt = Number.isFinite(targetSrcIndex) ? Math.max(0, Math.min(Number(targetSrcIndex), tab.entries.length)) : tab.entries.length;
    tab.entries.splice(insertAt, 0, entry);
    shortcutsData.tabs[this.activeType] = tab;

    await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, shortcutsData);
    ui.notifications?.info(`Added ${label} to ${TYPE_META[this.activeType]?.label ?? "Shortcuts"}.`);
  }

  async _promptAddCategory() {
    if (!game.user.isGM) return;

    const name = await promptText({
      title: "New Category",
      label: `Category name for ${TYPE_META[this.activeType]?.label ?? "this tab"}`,
      initial: ""
    });
    if (!name) return;

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    tab.categories = normalizeCategories(tab.categories);

    const id = foundry.utils.randomID();
    tab.categories.push({ id, name, icon: "fa-folder" });
    data.tabs[this.activeType] = tab;

    await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    this._renderGMTools();
    this.refreshAll();
  }

  async _promptAddDivider() {
    if (!game.user.isGM) return;

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    const activeCat = this._getActiveCategory(this.activeType, tab);

    const label = await promptText({
      title: "New Divider",
      label: "Divider label",
      initial: ""
    });
    if (!label) return;

    tab.entries = toIndexArray(tab.entries);
    tab.entries.push({
      label,
      uuid: "",
      icon: "",
      visibleToPlayers: true,
      categoryId: (activeCat === CATEGORY_ALL || activeCat === CATEGORY_BROWSE) ? "" : activeCat,
      entryType: "divider",
      dividerColor: "#a855f7"
    });
    data.tabs[this.activeType] = tab;

    await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
  }

  async _promptAddChooser() {
    if (!game.user.isGM) return;

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    const activeCat = this._getActiveCategory(this.activeType, tab);
    const activeCategory = (tab.categories ?? []).find(c => c.id === activeCat);
    const categoryName = activeCategory?.name || TYPE_META[this.activeType]?.label || "this tab";

    const dlg = new Dialog({
      title: "Add to Shortcut Panel",
      content: `<p>What would you like to create for <b>${foundry.utils.escapeHTML(categoryName)}</b>?</p>`,
      buttons: {
        category: {
          label: "Category",
          callback: async () => {
            await this._promptAddCategory();
          }
        },
        divider: {
          label: "Divider",
          callback: async () => {
            await this._promptAddDivider();
          }
        },
        cancel: {
          label: "Cancel"
        }
      },
      default: "divider"
    });
    dlg.render(true);
  }

  async _moveEntryToCategory(sourceIndex, categoryId) {
    if (!game.user.isGM || !Number.isFinite(Number(sourceIndex))) return;
    const idx = Number(sourceIndex);

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    tab.entries = toIndexArray(tab.entries);
    const entry = tab.entries[idx];
    if (!entry) return;

    const normalizedCategoryId = String(categoryId ?? "").trim();
    const valid = new Set((tab.categories ?? []).map(c => c.id));
    entry.categoryId = valid.has(normalizedCategoryId) ? normalizedCategoryId : "";
    data.tabs[this.activeType] = tab;
    await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
  }

  async _promptMoveEntryToCategory(sourceIndex) {
    if (!game.user.isGM || !Number.isFinite(Number(sourceIndex))) return;

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    tab.entries = toIndexArray(tab.entries);
    const entry = tab.entries[Number(sourceIndex)];
    if (!entry) return;

    const options = [
      { value: "", label: "Uncategorized" },
      ...(tab.categories ?? []).map(cat => ({ value: cat.id, label: cat.name }))
    ];

    const picked = await promptSelect({
      title: entry.entryType === "divider" ? "Send Divider to Category" : "Send Shortcut to Category",
      label: "Choose a category",
      options,
      initial: String(entry.categoryId ?? "").trim()
    });

    if (picked == null) return;
    await this._moveEntryToCategory(sourceIndex, picked);
  }

  async _openCategoryContextMenu(catId) {
    if (!game.user.isGM || !catId || catId === CATEGORY_ALL || catId === CATEGORY_BROWSE) return;

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    const cat = (tab.categories ?? []).find(c => c.id === catId);
    if (!cat) return;

    const renameCategory = async () => {
      const name = await promptText({ title: "Rename Category", label: "Category name", initial: cat.name });
      if (!name) return;
      cat.name = name;
      await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    };

    const setImage = async () => {
      openImageFilePicker({
        current: cat.image || "",
        callback: async (path) => {
          const latestRaw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
          const latestData = normalizeShortcutsData(deepClone(latestRaw));
          const latestTab = latestData.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
          const latestCat = (latestTab.categories ?? []).find(c => c.id === catId);
          if (!latestCat) return;

          latestCat.image = String(path).trim();
          latestCat.imageOffsetX = 0;
          latestCat.imageOffsetY = 0;
          latestCat.imageScale = 1;
          latestData.tabs[this.activeType] = latestTab;

          await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, latestData);
          this.refreshAll();
        }
      });
    };

    const alignImage = async () => {
      if (!cat.image) {
        ui.notifications?.warn("Set a category image first.");
        return;
      }
      await this._openCategoryImageAligner(catId);
    };

    const deleteCategory = async () => {
      const ok = await confirmDialog({
        title: "Delete Category",
        content: `<p>Delete <b>${foundry.utils.escapeHTML(cat.name)}</b>? Shortcuts in it will become uncategorized and stay in the panel.</p>`,
        yes: "Delete",
        no: "Cancel"
      });
      if (!ok) return;

      tab.categories = (tab.categories ?? []).filter(c => c.id !== catId);
      tab.entries = toIndexArray(tab.entries).map(e => String(e?.categoryId ?? "").trim() === catId ? { ...e, categoryId: "" } : e);
      await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
      await game.settings.set(MODULE_ID, SETTING_ACTIVE_CATS, {
        ...(game.settings.get(MODULE_ID, SETTING_ACTIVE_CATS) || {}),
        [this.activeType]: CATEGORY_BROWSE
      });
      this.refreshAll();
    };

    const dlg = new Dialog({
      title: `Category: ${cat.name}`,
      content: `<p>Choose what to do with <b>${foundry.utils.escapeHTML(cat.name)}</b>.</p>`,
      buttons: {
        rename: { label: "Rename", callback: () => renameCategory() },
        image: { label: cat.image ? "Change Image" : "Set Image", callback: () => setImage() },
        align: { label: "Align Image", callback: () => alignImage() },
        delete: { label: "Delete", callback: () => deleteCategory() },
        cancel: { label: "Cancel" }
      },
      default: cat.image ? "align" : "image"
    });
    dlg.render(true);
  }

  async _openCategoryImageAligner(catId) {
    if (!game.user.isGM || !catId) return;

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    const cat = (tab.categories ?? []).find(c => c.id === catId);
    if (!cat?.image) return ui.notifications?.warn("Set a category image first.");

    const state = {
      x: normalizeCategoryOffset(cat.imageOffsetX),
      y: normalizeCategoryOffset(cat.imageOffsetY),
      scale: normalizeCategoryImageScale(cat.imageScale)
    };

    const activeCard = Array.from(this._listEl?.querySelectorAll?.('.jsp-category-card') ?? []).find(el => el?.dataset?.cat === catId);
    const currentCardWidth = Math.max(140, Math.round(activeCard?.getBoundingClientRect?.().width || 0));
    let naturalWidth = 0;
    let naturalHeight = 0;

    const dlg = new Dialog({
      title: `Align Image: ${cat.name}`,
      content: `
        <div class="jsp-aligner">
          <div class="jsp-aligner-preview">
            <div class="jsp-aligner-frame" style="width:${currentCardWidth || 280}px; height:${currentCardWidth || 280}px;">
              <img class="jsp-aligner-img" src="${foundry.utils.escapeHTML(cat.image)}" alt="" />
              <div class="jsp-aligner-title">${foundry.utils.escapeHTML(cat.name)}</div>
            </div>
          </div>
          <div class="jsp-aligner-help">Drag to move the art. Use the mouse wheel to zoom. The image stays clipped inside the rounded square.</div>
          <div class="jsp-aligner-controls">
            <button type="button" class="jsp-btn compact" data-align-action="reset"><i class="fas fa-rotate-left"></i> Reset</button>
            <div class="jsp-aligner-zoom">Zoom <span data-align-zoom-value>${Math.round(state.scale * 100)}%</span></div>
          </div>
        </div>
      `,
      buttons: {
        confirm: {
          label: "Confirm",
          callback: async () => {
            cat.imageOffsetX = normalizeCategoryOffset(state.x);
            cat.imageOffsetY = normalizeCategoryOffset(state.y);
            cat.imageScale = normalizeCategoryImageScale(state.scale);
            await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
            this.refreshAll();
          }
        },
        cancel: { label: "Cancel" }
      },
      default: "confirm"
    });

    dlg.render(true);
    window.setTimeout(() => {
      const root = dlg.element?.[0];
      if (!root) return;
      const frame = root.querySelector('.jsp-aligner-frame');
      const img = root.querySelector('.jsp-aligner-img');
      const zoomValue = root.querySelector('[data-align-zoom-value]');
      const resetBtn = root.querySelector('[data-align-action="reset"]');
      if (!frame || !img) return;

      let dragging = false;
      let startX = 0;
      let startY = 0;
      let baseX = state.x;
      let baseY = state.y;

      const apply = () => {
        const rect = frame.getBoundingClientRect();
        if (naturalWidth && naturalHeight && rect.width && rect.height) {
          const clamped = clampCategoryImageTransform(state, naturalWidth, naturalHeight, rect.width, rect.height);
          state.x = clamped.x;
          state.y = clamped.y;
          state.scale = clamped.scale;
        }
        img.style.transform = `translate(${state.x}px, ${state.y}px) scale(${state.scale})`;
        if (zoomValue) zoomValue.textContent = `${Math.round(state.scale * 100)}%`;
      };

      const stopDrag = () => {
        dragging = false;
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', stopDrag);
      };

      const onMove = (ev) => {
        if (!dragging) return;
        state.x = baseX + (ev.clientX - startX);
        state.y = baseY + (ev.clientY - startY);
        apply();
      };

      img.addEventListener('load', () => {
        naturalWidth = img.naturalWidth || 1;
        naturalHeight = img.naturalHeight || 1;
        apply();
      });
      if (img.complete) {
        naturalWidth = img.naturalWidth || 1;
        naturalHeight = img.naturalHeight || 1;
        apply();
      }

      frame.addEventListener('mousedown', (ev) => {
        if (ev.button !== 0) return;
        ev.preventDefault();
        dragging = true;
        startX = ev.clientX;
        startY = ev.clientY;
        baseX = state.x;
        baseY = state.y;
        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', stopDrag);
      });

      frame.addEventListener('wheel', (ev) => {
        ev.preventDefault();
        state.scale = normalizeCategoryImageScale(state.scale + (ev.deltaY < 0 ? 0.08 : -0.08));
        apply();
      }, { passive: false });

      resetBtn?.addEventListener('click', (ev) => {
        ev.preventDefault();
        state.x = 0;
        state.y = 0;
        state.scale = 1;
        apply();
      });
    }, 0);
  }


  async _openEntryContextMenu(sourceIndex) {
    if (!game.user.isGM || !Number.isFinite(Number(sourceIndex))) return;
    const idx = Number(sourceIndex);

    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType] ?? defaultShortcutsData().tabs[this.activeType];
    tab.entries = toIndexArray(tab.entries);
    const entry = tab.entries[idx];
    if (!entry) return;


    const renameEntry = async () => {
      const title = entry.entryType === "divider" ? "Rename Divider" : "Rename Shortcut";
      const label = await promptText({ title, label: "Label", initial: entry.label || "" });
      if (!label) return;
      entry.label = label;
      await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    };

    const moveEntry = async () => {
      await this._promptMoveEntryToCategory(idx);
    };

    const toggleVisibility = async () => {
      entry.visibleToPlayers = !coerceBool(entry.visibleToPlayers, true);
      await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    };

    const setDividerColor = async () => {
      const color = await promptText({ title: "Divider Color", label: "Hex color", initial: entry.dividerColor || "#a855f7" });
      if (!color) return;
      entry.dividerColor = String(color).trim();
      await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    };

    const removeEntry = async () => {
      const ok = await confirmDialog({
        title: entry.entryType === "divider" ? "Delete Divider" : "Delete Shortcut",
        content: `<p>Remove <b>${foundry.utils.escapeHTML(entry.label || "this entry")}</b> from the panel?</p>`,
        yes: "Remove",
        no: "Cancel"
      });
      if (!ok) return;
      tab.entries.splice(idx, 1);
      await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    };

    const buttons = entry.entryType === "divider"
      ? {
          rename: { label: "Rename", callback: () => renameEntry() },
          color: { label: "Color", callback: () => setDividerColor() },
          move: { label: "Send to Category", callback: () => moveEntry() },
          delete: { label: "Delete", callback: () => removeEntry() },
          cancel: { label: "Cancel" }
        }
      : {
          rename: { label: "Rename", callback: () => renameEntry() },
          move: { label: "Send to Category", callback: () => moveEntry() },
          visibility: { label: coerceBool(entry.visibleToPlayers, true) ? "GM Only" : "Visible to Players", callback: () => toggleVisibility() },
          delete: { label: "Delete", callback: () => removeEntry() },
          cancel: { label: "Cancel" }
        };

    const dlg = new Dialog({
      title: entry.entryType === "divider" ? `Divider: ${entry.label || "(unnamed)"}` : `Shortcut: ${entry.label || "(unnamed)"}`,
      content: `<p>Choose what to do with <b>${foundry.utils.escapeHTML(entry.label || "this entry")}</b>.</p>`,
      buttons,
      default: "rename"
    });
    dlg.render(true);
  }



  async _reorderWithinVisibleSubset(fromSrcIndex, toSrcIndex, visibleIndices) {
    if (!game.user.isGM) return;
    const fromSrc = Number(fromSrcIndex);
    if (!Number.isFinite(fromSrc)) return;

    const vis = Array.isArray(visibleIndices) ? visibleIndices.slice() : [];
    // Ensure only in-range indices are used
    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType];
    if (!tab) return;

    const entries = toIndexArray(tab.entries);
    const visInRange = vis.filter(i => Number.isFinite(i) && i >= 0 && i < entries.length);

    const fromPos = visInRange.indexOf(fromSrc);
    if (fromPos === -1) return;

    let toPos;
    if (toSrcIndex === null || toSrcIndex === undefined) {
      toPos = visInRange.length; // drop to end
    } else {
      const toSrc = Number(toSrcIndex);
      toPos = visInRange.indexOf(toSrc);
      if (toPos === -1) toPos = visInRange.length;
    }

    if (toPos === fromPos) return;

    const subset = visInRange.map(i => entries[i]);
    const [moved] = subset.splice(fromPos, 1);
    let insertPos = toPos;
    if (fromPos < toPos) insertPos = Math.max(0, insertPos - 1);
    insertPos = Math.min(Math.max(insertPos, 0), subset.length);
    subset.splice(insertPos, 0, moved);

    for (let k = 0; k < visInRange.length; k++) {
      entries[visInRange[k]] = subset[k];
    }

    tab.entries = entries;
    await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    this.refreshAll();
  }

  _renderTabs() {
    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));

    const currentIndex = Math.max(0, TYPES.indexOf(this.activeType));
    const activeKey = TYPES[currentIndex] ?? "actors";
    const activeMeta = TYPE_META[activeKey] ?? TYPE_META.actors;
    const activeTab = data.tabs?.[activeKey] ?? defaultShortcutsData().tabs[activeKey];
    const activeCat = this._getActiveCategory(activeKey, activeTab);
    const tabIcon = cleanIcon(activeTab?.icon ?? activeMeta.icon) || activeMeta.icon;

    const setType = async (typeKey) => {
      this.activeType = typeKey;
      await game.settings.set(MODULE_ID, SETTING_ACTIVE_TYPE, typeKey);
      await game.settings.set(MODULE_ID, SETTING_ACTIVE_CATS, {
        ...(game.settings.get(MODULE_ID, SETTING_ACTIVE_CATS) || {}),
        [typeKey]: CATEGORY_BROWSE
      });
      this._renderTabs();
      this._renderCategories();
      this._renderGMTools();
      this.refreshList();
    };

    const goBackToCategories = async () => {
      await game.settings.set(MODULE_ID, SETTING_ACTIVE_CATS, {
        ...(game.settings.get(MODULE_ID, SETTING_ACTIVE_CATS) || {}),
        [this.activeType]: CATEGORY_BROWSE
      });
      this.refreshAll();
    };

    const prevKey = TYPES[(currentIndex - 1 + TYPES.length) % TYPES.length];
    const nextKey = TYPES[(currentIndex + 1) % TYPES.length];

    if (activeCat === CATEGORY_BROWSE) {
      this._tabsEl.innerHTML = `
        <div class="jsp-tab-shell jsp-tab-shell-carousel" data-type="${foundry.utils.escapeHTML(activeKey)}" title="${foundry.utils.escapeHTML(activeMeta.label)}">
          <button type="button" class="jsp-tab-nav jsp-tab-nav-inside jsp-tab-nav-prev" data-dir="prev" title="${foundry.utils.escapeHTML(TYPE_META[prevKey]?.label ?? "Previous Tab")}">
            <i class="fas fa-chevron-left"></i>
          </button>
          <div class="jsp-tab-current active">
            <span class="jsp-tab-current-icon">
              ${isImageIcon(tabIcon)
                ? `<img class="jsp-tab-img" src="${foundry.utils.escapeHTML(tabIcon)}" alt="" />`
                : `<i class="fas ${foundry.utils.escapeHTML(tabIcon)}"></i>`}
            </span>
            <span class="jsp-tab-current-label">${foundry.utils.escapeHTML(activeMeta.label)}</span>
          </div>
          <button type="button" class="jsp-tab-nav jsp-tab-nav-inside jsp-tab-nav-next" data-dir="next" title="${foundry.utils.escapeHTML(TYPE_META[nextKey]?.label ?? "Next Tab")}">
            <i class="fas fa-chevron-right"></i>
          </button>
        </div>
      `;

      this._tabsEl.querySelector('[data-dir="prev"]')?.addEventListener("click", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        void setType(prevKey);
      });

      this._tabsEl.querySelector('[data-dir="next"]')?.addEventListener("click", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        void setType(nextKey);
      });
    } else {
      const showAddControl = game.user.isGM;
      this._tabsEl.innerHTML = `
        <div class="jsp-tab-shell jsp-tab-shell-back" title="Back to ${foundry.utils.escapeHTML(activeMeta.label)} categories">
          <button type="button" class="jsp-tab-back-main">
            <span class="jsp-tab-current-icon"><i class="fas fa-arrow-left"></i></span>
            <span class="jsp-tab-current-label">Back</span>
          </button>
          ${showAddControl ? `<button type="button" class="jsp-tab-add-inline" title="Add Category or Divider"><i class="fas fa-plus"></i></button>` : ""}
        </div>
      `;

      this._tabsEl.querySelector('.jsp-tab-back-main')?.addEventListener("click", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        void goBackToCategories();
      });

      this._tabsEl.querySelector('.jsp-tab-add-inline')?.addEventListener("click", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        void this._promptAddChooser();
      });
    }

    this._syncActiveTabUI();
  }

  _renderCategories() {
    const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
    const data = normalizeShortcutsData(deepClone(raw));
    const tab = data.tabs?.[this.activeType];
    if (!tab) return;

    const activeCat = this._getActiveCategory(this.activeType, tab);
    this._catsEl.innerHTML = "";

    this._syncActiveCategoryUI(activeCat);
    this._updateBodyRailState();
  }

  _updateBodyRailState() {
    if (!this._bodyEl || !this._catsEl) return;
    const hasRailButtons = this._catsEl.childElementCount > 0;
    this._bodyEl.classList.toggle("jsp-no-rail", !hasRailButtons);
  }

  _getActiveCategory(typeKey, tabData) {
    const raw = game.settings.get(MODULE_ID, SETTING_ACTIVE_CATS) || {};
    const current = String(raw?.[typeKey] ?? CATEGORY_BROWSE).trim() || CATEGORY_BROWSE;

    if (current === "all") return CATEGORY_BROWSE;
    if (current === CATEGORY_BROWSE || current === CATEGORY_ALL) return current;

    const valid = new Set((tabData?.categories ?? []).map(c => c.id));
    return valid.has(current) ? current : CATEGORY_BROWSE;
  }

  _setActiveCategory(typeKey, catId) {
    const raw = game.settings.get(MODULE_ID, SETTING_ACTIVE_CATS) || {};
    raw[typeKey] = catId;
    game.settings.set(MODULE_ID, SETTING_ACTIVE_CATS, raw);
  }

  _syncActiveCategoryUI(activeCat) {
    const cur = activeCat ?? this._getActiveCategory(this.activeType, normalizeShortcutsData(game.settings.get(MODULE_ID, SETTING_SHORTCUTS)).tabs?.[this.activeType]);
    const browseActive = cur === CATEGORY_BROWSE;
    for (const el of this._catsEl.querySelectorAll(".jsp-side-btn")) {
      if (el.dataset.action === "browse-categories") el.classList.toggle("active", browseActive);
    }
  }


  _syncActiveTabUI() {
    const current = this._tabsEl.querySelector(".jsp-tab-current");
    if (current) current.classList.add("active");
  }

  
  _position() {
    const uiRight = document.getElementById("ui-right");
    const sidebar = document.getElementById("sidebar");
    const sidebarTabs = document.getElementById("sidebar-tabs");

    // In v13, the collapse state may be represented on different elements depending on theme/modules.
    const collapsed = !!(
      sidebar?.classList?.contains("collapsed") ||
      uiRight?.classList?.contains("collapsed") ||
      document.body?.classList?.contains("sidebar-collapsed")
    );

    const rectUI = uiRight?.getBoundingClientRect?.();
    const rectSB = sidebar?.getBoundingClientRect?.();
    const rectTabs = sidebarTabs?.getBoundingClientRect?.();

    // Compute the distance from the right edge of the viewport to the left edge of the sidebar.
    // Using "left" is more reliable than container widths across themes/modules.
    const candidates = [];
    // Prefer the sidebar tab strip if present (it's the true left edge of the whole sidebar UI).
    if (rectTabs && Number.isFinite(rectTabs.left)) candidates.push(window.innerWidth - rectTabs.left);
    if (rectSB && Number.isFinite(rectSB.left)) candidates.push(window.innerWidth - rectSB.left);
    if (rectUI && Number.isFinite(rectUI.left)) candidates.push(window.innerWidth - rectUI.left);

    const finite = candidates.filter(n => Number.isFinite(n) && n >= 0);
    let rightDist = finite.length ? Math.min(...finite) : 300;

    // If we detect collapsed, clamp so the panel hugs the edge.
    if (collapsed) rightDist = Math.min(rightDist, 46);

    // Small spacing between the panel and the sidebar.
    const GAP = 2;
    const rightPx = Math.max(0, Math.round(rightDist) + GAP);
    this.element.style.right = `${rightPx}px`;
  }

  _installObservers() {
    const sidebar = document.getElementById("sidebar");
    const uiRight = document.getElementById("ui-right");
    const sidebarTabs = document.getElementById("sidebar-tabs");

    // Attribute mutations (class/style) on sidebar/ui-right.
    this._observer = new MutationObserver(() => {
      if (!this.visible) return;
      this._position();
    });
    if (sidebar) this._observer.observe(sidebar, { attributes: true, attributeFilter: ["class", "style"] });
    if (uiRight) this._observer.observe(uiRight, { attributes: true, attributeFilter: ["class", "style"] });
    if (sidebarTabs) this._observer.observe(sidebarTabs, { attributes: true, attributeFilter: ["class", "style"] });

    // Some setups toggle collapse state on <body>.
    this._bodyObserver = new MutationObserver(() => {
      if (!this.visible) return;
      this._position();
    });
    this._bodyObserver.observe(document.body, { attributes: true, attributeFilter: ["class"] });

    // Size changes (best signal for sidebar collapse/expand).
    if (window.ResizeObserver) {
      this._resizeObserver = new ResizeObserver(() => {
        if (!this.visible) return;
        this._position();
      });
      if (uiRight) this._resizeObserver.observe(uiRight);
      if (sidebar) this._resizeObserver.observe(sidebar);
      if (sidebarTabs) this._resizeObserver.observe(sidebarTabs);
    }

    window.addEventListener("resize", () => {
      if (!this.visible) return;
      this._position();
    });
  }
}

/* -------------------------------------------- */
/* Manager                                      */
/* -------------------------------------------- */

class ShortcutsManager extends FormApplication {

  static open() {
    return ui.notifications?.info("The old Shortcuts Manager has been retired. Drag and drop entries directly into ChristheDM's Shortcut Panel instead.");
  }

  constructor(options = {}) {
    super(options);
    this._draftData = null;
    this._activeTab = "journals";
    this._activeCategoryByType = Object.fromEntries(TYPES.map(t => [t, "all"]));
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "journal-shortcuts-manager",
      title: "Shortcuts Manager",
      template: `modules/${MODULE_ID}/templates/manager.hbs`,
      classes: ["journal-shortcuts-panel", "manager-app"],
      width: 820,
      height: 620,
      resizable: true,
      closeOnSubmit: false,
      submitOnChange: false,
      submitOnClose: false
    });
  }

  _getSetting() {
    return normalizeShortcutsData(deepClone(game.settings.get(MODULE_ID, SETTING_SHORTCUTS)));
  }

  _syncDraftFromForm() {
    try {
      const fd = new FormDataExtended(this.form).object;
      const expanded = foundry.utils.expandObject(fd);
      this._draftData = normalizeShortcutsData(expanded.shortcuts);
    } catch (e) {
      console.warn("Shortcut Manager: could not sync from form; keeping prior draft.", e);
    }
  }

  async getData(options = {}) {
    const data = this._draftData ?? this._getSetting();

    const types = TYPES.map((key) => {
      const meta = TYPE_META[key];
      const icon = cleanIcon(data.tabs?.[key]?.icon ?? meta.icon) || meta.icon;
      return {
        key,
        label: meta.label,
        icon,
        iconIsImage: isImageIcon(icon)
      };
    });

    const panels = [];
    for (const key of TYPES) {
      const meta = TYPE_META[key];
      const tab = data.tabs?.[key] ?? defaultShortcutsData().tabs[key];

      const tabIconRaw = cleanIcon(tab.icon ?? meta.icon) || meta.icon;
      const categoriesBase = normalizeCategories(tab.categories);
      const categories = categoriesBase.map((c) => ({
        ...c,
        icon: cleanIcon(c.icon) || "fa-folder",
        iconIsImage: isImageIcon(c.icon),
        iconRaw: c.icon
      }));

      const entriesRaw = normalizeEntries(tab.entries, categoriesBase);
      const entries = [];
      for (let i = 0; i < entriesRaw.length; i++) {
        const e = entriesRaw[i];
        const selectedName = e.uuid ? (await resolveName(e.uuid)) : "";
        entries.push({
          index: i,
          label: e.label,
          uuid: e.uuid,
          icon: cleanIcon(e.icon),
          iconRaw: e.icon,
          iconIsImage: isImageIcon(e.icon),
          visibleToPlayers: coerceBool(e.visibleToPlayers, true),
          categoryId: e.categoryId || "",
          entryType: e.entryType || "shortcut",
          dividerColor: e.dividerColor || "#a855f7",
          selectedName
        });
      }

      panels.push({
        key,
        label: meta.label,
        icon: tabIconRaw,
        iconRaw: tabIconRaw,
        iconIsImage: isImageIcon(tabIconRaw),
        iconFaFallback: meta.icon,
        categories,
        entries
      });
    }

    return {
      types,
      panels,
      activeTab: this._activeTab,
      activeCategoryByType: this._activeCategoryByType,
      shortcuts: data
    };
  }
  activateListeners(html) {
    super.activateListeners(html);

    // Tab switching (no re-render; preserves unsaved edits in the DOM)
    html.on("click", ".jsp-tab-btn", (ev) => {
      ev.preventDefault();
      const tab = ev.currentTarget?.dataset?.tab;
      if (!TYPES.includes(tab)) return;
      this._activeTab = tab;

      html.find(".jsp-tab-btn").removeClass("active");
      html.find(`.jsp-tab-btn[data-tab='${tab}']`).addClass("active");
      html.find(".jsp-tab-panel").removeClass("active");
      html.find(`.jsp-tab-panel[data-tab='${tab}']`).addClass("active");
    });

    // Category selection (DOM-only filtering; preserves unsaved edits)
    html.on("click", ".jsp-cat-btn", (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      const type = btn?.dataset?.type;
      const cat = btn?.dataset?.cat;
      if (!TYPES.includes(type) || cat == null) return;
      this._activeCategoryByType[type] = cat;

      const panel = btn.closest(".jsp-tab-panel");
      panel?.querySelectorAll(".jsp-cat-btn").forEach((b) => b.classList.toggle("active", b === btn));
      this._applyCategoryFilter(panel, type, cat);
    });

    // Primary action buttons
    html.on("click", "[data-action]", async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      const action = btn?.dataset?.action;
      if (!action) return;

      // Some actions only mutate DOM and should not force a draft sync first.
      const noSync = new Set(["entry-manage", "clear-target"]);
      if (!noSync.has(action)) this._syncDraftFromForm();

      if (action === "add") return this._onAdd();
      if (action === "delete") return this._onDelete(btn);
      if (action === "move-up") return this._onMove(btn, -1);
      if (action === "move-down") return this._onMove(btn, 1);
      if (action === "clear-target") return this._onClearTarget(btn);

      if (action === "entry-manage") return this._onEntryManage(btn);

      if (action === "edit-tab-icon") return this._onEditTabIcon(btn);

      if (action === "cat-quick-add") return this._onCategoryQuickAdd(btn);
      if (action === "cat-manage") return this._onOpenCategoryManager(btn);
    });

    // Drag & drop onto dropzones
    html.on("dragover", ".jsp-dropzone", (ev) => {
      ev.preventDefault();
      ev.currentTarget?.classList?.add("dragover");
    });
    html.on("dragleave", ".jsp-dropzone", (ev) => {
      ev.preventDefault();
      ev.currentTarget?.classList?.remove("dragover");
    });
    html.on("drop", ".jsp-dropzone", (ev) => this._onDrop(ev));

    // Apply filters for the current state after rendering
    for (const t of TYPES) {
      const cat = this._activeCategoryByType[t] ?? "all";
      const panel = html[0].querySelector(`.jsp-tab-panel[data-tab='${t}']`);
      if (panel) {
        const btn =
          panel.querySelector(`.jsp-cat-btn[data-cat='${cat}']`) ||
          panel.querySelector(".jsp-cat-btn[data-cat='all']");
        if (btn) panel.querySelectorAll(".jsp-cat-btn").forEach((b) => b.classList.toggle("active", b === btn));
        this._applyCategoryFilter(panel, t, cat);
      }
    }
  }


  _applyCategoryFilter(panelEl, typeKey, catId) {
    const rows = panelEl?.querySelectorAll?.(`.jsp-row[data-type='${typeKey}']`) ?? [];
    for (const r of rows) {
      const matches = (catId === "all") || ((r.dataset.cat || "") === catId);
      r.style.display = matches ? "" : "none";
    }
  }

  _onAdd() {
    const data = this._draftData ?? this._getSetting();
    const t = this._activeTab;

    const activeCat = this._activeCategoryByType[t] ?? "all";
    const categoryId = (activeCat === "all") ? "" : activeCat;

    data.tabs[t] = data.tabs[t] ?? defaultShortcutsData().tabs[t];
    data.tabs[t].entries = toIndexArray(data.tabs[t].entries);
    data.tabs[t].entries.push({
      label: "",
      uuid: "",
      icon: "",
      visibleToPlayers: true,
      categoryId
    });

    this._draftData = normalizeShortcutsData(data);
    this.render(false);
  }

  _onDelete(btn) {
    const row = btn?.closest(".jsp-row");
    if (!row) return;
    const type = row.dataset.type;
    const idx = Number(row.dataset.index);
    if (!TYPES.includes(type) || !Number.isFinite(idx)) return;

    const rowEl = this.form?.querySelector?.(`.jsp-row[data-type='${type}'][data-index='${idx}']`);
    const entryTypeHidden = rowEl?.querySelector?.("input.jsp-entry-type");
    const entryType = (String(entryTypeHidden?.value ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut";

    const data = this._draftData ?? this._getSetting();
    const entries = toIndexArray(data.tabs?.[type]?.entries);
    entries.splice(idx, 1);
    data.tabs[type].entries = entries;

    this._draftData = normalizeShortcutsData(data);
    this.render(false);
  }

  _onMove(btn, delta) {
    const row = btn?.closest(".jsp-row");
    if (!row) return;
    const type = row.dataset.type;
    const idx = Number(row.dataset.index);
    if (!TYPES.includes(type) || !Number.isFinite(idx)) return;

    const rowEl = this.form?.querySelector?.(`.jsp-row[data-type='${type}'][data-index='${idx}']`);
    const entryTypeHidden = rowEl?.querySelector?.("input.jsp-entry-type");
    const entryType = (String(entryTypeHidden?.value ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut";

    const data = this._draftData ?? this._getSetting();
    const entries = toIndexArray(data.tabs?.[type]?.entries);
    const j = idx + delta;
    if (j < 0 || j >= entries.length) return;

    const tmp = entries[idx];
    entries[idx] = entries[j];
    entries[j] = tmp;
    data.tabs[type].entries = entries;

    this._draftData = normalizeShortcutsData(data);
    this.render(false);
  }

  _onToggleVisible(btn) {
    const row = btn?.closest(".jsp-row");
    if (!row) return;

    const hidden = row.querySelector("input.jsp-entry-vis");
    const cur = coerceBool(hidden?.value, true);
    const next = !cur;
    if (hidden) hidden.value = next ? "1" : "0";

    btn.classList.toggle("danger", !next);
    const i = btn.querySelector("i");
    if (i) {
      i.classList.toggle("fa-eye", next);
      i.classList.toggle("fa-eye-slash", !next);
    }
    btn.title = next ? "Visible to Players" : "GM Only";
  }

  async _onEditEntryIcon(btn) {
    const row = btn?.closest(".jsp-row");
    if (!row) return;
    const type = row.dataset.type;
    const idx = Number(row.dataset.index);
    if (!TYPES.includes(type) || !Number.isFinite(idx)) return;

    const rowEl = this.form?.querySelector?.(`.jsp-row[data-type='${type}'][data-index='${idx}']`);
    const entryTypeHidden = rowEl?.querySelector?.("input.jsp-entry-type");
    const entryType = (String(entryTypeHidden?.value ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut";

    const hidden = row.querySelector("input.jsp-entry-icon");
    const initial = hidden?.value ?? "";
    const v = await promptText({
      title: "Entry Icon",
      label: "Enter a Font Awesome class (e.g. fa-star) or an image path",
      initial
    });
    if (v == null) return;
    if (hidden) hidden.value = cleanIcon(v);
  }

  async _onEditTabIcon(btn) {
    const type = btn?.dataset?.type ?? this._activeTab;
    if (!TYPES.includes(type)) return;

    const data = this._draftData ?? this._getSetting();
    const cur = cleanIcon(data.tabs?.[type]?.icon ?? TYPE_META[type]?.icon ?? "");
    const v = await promptText({
      title: "Tab Icon",
      label: "Enter a Font Awesome class (e.g. fa-book) or an image path",
      initial: cur
    });
    if (v == null) return;

    data.tabs[type].icon = cleanIcon(v);
    this._draftData = normalizeShortcutsData(data);
    this.render(false);
  }

  async _onCategoryAdd(btn) {
    const type = btn?.dataset?.type ?? this._activeTab;
    if (!TYPES.includes(type)) return;

    const data = this._draftData ?? this._getSetting();
    const tab = data.tabs?.[type] ?? defaultShortcutsData().tabs[type];
    tab.categories = normalizeCategories(tab.categories);

    const name = await promptText({
      title: "New Category",
      label: "Category name",
      initial: ""
    });
    if (!name) return;

    const id = foundry.utils.randomID();
    tab.categories.push({ id, name, icon: "fa-folder" });
    data.tabs[type] = tab;

    this._draftData = normalizeShortcutsData(data);
    this._activeCategoryByType[type] = id;
    this.render(false);
  }

  async _onCategoryRename(btn) {
    const type = btn?.dataset?.type ?? this._activeTab;
    if (!TYPES.includes(type)) return;

    const active = this._activeCategoryByType[type] ?? "all";
    if (active === "all") {
      ui.notifications?.warn("Select a category first.");
      return;
    }

    const data = this._draftData ?? this._getSetting();
    const tab = data.tabs?.[type] ?? defaultShortcutsData().tabs[type];
    tab.categories = normalizeCategories(tab.categories);

    const cat = tab.categories.find(c => c.id === active);
    if (!cat) return;

    const name = await promptText({
      title: "Rename Category",
      label: "Category name",
      initial: cat.name
    });
    if (!name) return;

    cat.name = name;
    data.tabs[type] = tab;

    this._draftData = normalizeShortcutsData(data);
    this.render(false);
  }

  async _onCategoryDelete(btn) {
    const type = btn?.dataset?.type ?? this._activeTab;
    if (!TYPES.includes(type)) return;

    const active = this._activeCategoryByType[type] ?? "all";
    if (active === "all") {
      ui.notifications?.warn("Select a category to delete.");
      return;
    }
    const ok = await confirmDialog({
      title: "Delete Category",
      content: `<p>Delete this category? Shortcuts in it will become <b>uncategorized</b> (they will still appear under <b>All</b>).</p>`,
      yes: "Delete",
      no: "Cancel"
    });
    if (!ok) return;

    const data = this._draftData ?? this._getSetting();
    const tab = data.tabs?.[type] ?? defaultShortcutsData().tabs[type];
    tab.categories = normalizeCategories(tab.categories);

    tab.categories = tab.categories.filter(c => c.id !== active);
    tab.entries = toIndexArray(tab.entries).map(e => {
      let cid = String(e?.categoryId ?? "").trim();
      if (cid === "default" || cid.toLowerCase() === "default") cid = "";
      if (cid === active) return { ...e, categoryId: "" };
      return e;
    });

    data.tabs[type] = tab;

    this._draftData = normalizeShortcutsData(data);
    this._activeCategoryByType[type] = "all";
    this.render(false);
  }

  async _onCategoryIcon(btn) {
    const type = btn?.dataset?.type ?? this._activeTab;
    if (!TYPES.includes(type)) return;

    const active = this._activeCategoryByType[type] ?? "all";
    if (active === "all") {
      ui.notifications?.warn("Select a category first.");
      return;
    }

    const data = this._draftData ?? this._getSetting();
    const tab = data.tabs?.[type] ?? defaultShortcutsData().tabs[type];
    tab.categories = normalizeCategories(tab.categories);

    const cat = tab.categories.find(c => c.id === active);
    if (!cat) return;

    const v = await promptText({
      title: "Category Icon",
      label: "Enter a Font Awesome class (e.g. fa-folder) or an image path",
      initial: cat.icon
    });
    if (v == null) return;

    cat.icon = cleanIcon(v);
    data.tabs[type] = tab;

    this._draftData = normalizeShortcutsData(data);
    this.render(false);
  }

  /**
   * Read Foundry drag data from a jQuery-wrapped drop event.
   * Supports both TextEditor.getDragEventData and plain JSON in dataTransfer.
   */
  _readDragData(ev) {
    return readFoundryDragData(ev);
  }

  _acceptedDocTypes(tabKey) {
    return acceptedDocTypesForTab(tabKey);
  }

  _extractUuidFromDragData(data) {
    return extractUuidFromDragData(data);
  }

    async _onDrop(ev) {
    ev.preventDefault();
    ev.stopPropagation();

    const dz = ev?.currentTarget;
    dz?.classList?.remove("dragover");
    if (!dz) return;

    const type = dz.dataset.type;
    const idx = Number(dz.dataset.index);
    if (!TYPES.includes(type) || !Number.isFinite(idx)) return;

    const rowEl = this.form?.querySelector?.(`.jsp-row[data-type='${type}'][data-index='${idx}']`);
    const entryTypeHidden = rowEl?.querySelector?.("input.jsp-entry-type");
    const entryType = (String(entryTypeHidden?.value ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut";

    const data = this._readDragData(ev);
    const uuid = this._extractUuidFromDragData(data);
    if (!uuid) return;

    // Validate doc type for this tab
    const accepted = this._acceptedDocTypes(type);
    const docType = data?.type ?? (data?.documentName ?? data?.documentType);
    if (docType && accepted.size && !accepted.has(docType)) {
      ui.notifications?.warn(`That drop isn't a valid ${TYPE_META[type]?.dropHint ?? "document"} for this tab.`);
      return;
    }

    await this._setRowTarget(type, idx, uuid);
  }

  async _setRowTarget(type, idx, uuid) {
    const row = this.form?.querySelector?.(`.jsp-row[data-type='${type}'][data-index='${idx}']`);
    if (!row) return;

    const hidden = row.querySelector("input.jsp-uuid");
    if (hidden) hidden.value = uuid;

    // Update display
    const dz = row.querySelector(".jsp-dropzone");
    const inner = dz?.querySelector(".jsp-dropzone-inner");
    const nameText = (await resolveName(uuid)) || "Selected";
    const icon = dz?.dataset?.icon || TYPE_META[type]?.icon || "fa-link";
    if (inner) {
      inner.innerHTML = `<i class="fas ${foundry.utils.escapeHTML(icon)}"></i><span class="jsp-dropzone-name">${foundry.utils.escapeHTML(nameText)}</span>`;
    }

    const selectedEl = row.querySelector(".jsp-selected");
    if (selectedEl) {
      selectedEl.innerHTML = `Selected: <span class="jsp-selected-name">${foundry.utils.escapeHTML(nameText)}</span>`;
    }
  }

  _onClearTarget(btn) {
    const row = btn?.closest(".jsp-row");
    if (!row) return;
    const hidden = row.querySelector("input.jsp-uuid");
    if (hidden) hidden.value = "";

    const dz = row.querySelector(".jsp-dropzone");
    const inner = dz?.querySelector(".jsp-dropzone-inner");
    const label = dz?.dataset?.label || TYPE_META[row.dataset.type]?.label || "Target";
    if (inner) {
      inner.innerHTML = `<i class="fas fa-hand-pointer"></i><span class="jsp-muted">Drag &amp; drop ${foundry.utils.escapeHTML(label)} here</span>`;
    }

    const selectedEl = row.querySelector(".jsp-selected");
    if (selectedEl) selectedEl.innerHTML = `<span class="jsp-muted">Selected: —</span>`;
  }

  async _onEntryManage(btn) {
    const row = btn?.closest?.(".jsp-row");
    if (!row) return;

    const type = row.dataset.type;
    if (!TYPES.includes(type)) return;

    // Keep draft in sync so we have up-to-date categories
    this._syncDraftFromForm();
    const data = this._draftData ?? this._getSetting();
    const tab = data.tabs?.[type] ?? defaultShortcutsData().tabs[type];
    const categories = normalizeCategories(tab.categories);

    const iconHidden = row.querySelector("input.jsp-entry-icon");
    const visHidden = row.querySelector("input.jsp-entry-vis");
    const catHidden = row.querySelector("input.jsp-entry-cat");
    const typeHidden = row.querySelector("input.jsp-entry-type");
    const divColorHidden = row.querySelector("input.jsp-entry-divcolor");

    const currentIcon = iconHidden?.value ?? "";
    const currentVis = coerceBool(visHidden?.value, true);
    const currentCat = String(catHidden?.value ?? "").trim();

    const currentEntryType = (String(typeHidden?.value ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut";
    const currentDivColor = (String(divColorHidden?.value ?? "").trim() || "#a855f7");

    const options = [
      `<option value="">(No category — shows only in All)</option>`,
      ...categories.map(c => `<option value="${foundry.utils.escapeHTML(c.id)}">${foundry.utils.escapeHTML(c.name)}</option>`)
    ].join("");

    const content = `
      <form class="jsp-entry-manage">
        <div class="form-group">
          <label>Visibility</label>
          <div class="form-fields">
            <label class="checkbox">
              <input type="checkbox" name="visible" ${currentVis ? "checked" : ""} />
              <span>Visible to players</span>
            </label>
          </div>
          <p class="notes">If unchecked, only the GM will see this shortcut in the overlay.</p>
        </div>

        <div class="form-group">
          <label>Entry Type</label>
          <div class="form-fields">
            <select name="entryType">
              <option value="shortcut" ${currentEntryType === "shortcut" ? "selected" : ""}>Shortcut</option>
              <option value="divider" ${currentEntryType === "divider" ? "selected" : ""}>Divider</option>
            </select>
          </div>
          <p class="notes">Dividers are non-clickable labels used to separate groups in the overlay.</p>
        </div>

        <div class="form-group">
          <label>Divider Color</label>
          <div class="form-fields">
            <input type="color" name="dividerColor" value="${foundry.utils.escapeHTML(currentDivColor)}" />
            <input type="text" name="dividerColorText" value="${foundry.utils.escapeHTML(currentDivColor)}" placeholder="#a855f7" />
          </div>
          <p class="notes">Used only when Entry Type is <b>Divider</b>.</p>
        </div>


        <div class="form-group">
          <label>Entry Icon</label>
          <div class="form-fields">
            <input type="text" name="icon" value="${foundry.utils.escapeHTML(currentIcon)}" placeholder="fa-book (or /path/to/icon.png)" />
          </div>
          <p class="notes">Font Awesome class (fa-*) or an image path.</p>
        </div>

        <div class="form-group">
          <label>Category</label>
          <div class="form-fields">
            <select name="category">${options}</select>
          </div>
          <p class="notes">Uncategorized shortcuts appear only under <b>All</b>.</p>
        </div>
      </form>
    `;

    const dlg = new Dialog({
      title: "Manage Shortcut",
      content,
      buttons: {
        save: {
          icon: "<i class='fas fa-check'></i>",
          label: "Save",
          callback: (html) => {
            const form = html[0]?.querySelector("form.jsp-entry-manage");
            if (!form) return;

            const visible = !!form.querySelector("input[name='visible']")?.checked;
            const icon = cleanIcon(form.querySelector("input[name='icon']")?.value ?? "");
            const categoryId = String(form.querySelector("select[name='category']")?.value ?? "").trim();

            const entryType = (String(form.querySelector("select[name='entryType']")?.value ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut";
            const colorText = String(form.querySelector("input[name='dividerColorText']")?.value ?? "").trim();
            const colorPick = String(form.querySelector("input[name='dividerColor']")?.value ?? "").trim();
            const dividerColor = (colorPick || colorText || "#a855f7");


            if (iconHidden) iconHidden.value = icon;
            if (visHidden) visHidden.value = visible ? "1" : "0";
            if (catHidden) catHidden.value = categoryId;
            if (typeHidden) typeHidden.value = entryType;
            if (divColorHidden) divColorHidden.value = dividerColor;

            try {
              const sw = row.querySelector('.jsp-divider-swatch');
              if (sw) sw.style.background = dividerColor;
            } catch (_) {}

            row.dataset.cat = categoryId;
            row.classList.toggle("gm-only", !visible);

            const panel = row.closest(".jsp-tab-panel");
            const active = this._activeCategoryByType[type] ?? "all";
            if (panel) this._applyCategoryFilter(panel, type, active);
          }
        },
        cancel: {
          icon: "<i class='fas fa-times'></i>",
          label: "Cancel"
        }
      },
      default: "save",
      render: (html) => {
        try {
          const root = html[0];
          const sel = root?.querySelector("select[name='category']");
          if (sel) sel.value = currentCat;

          const pick = root?.querySelector("input[name='dividerColor']");
          const txt = root?.querySelector("input[name='dividerColorText']");
          if (pick && txt) {
            const syncFromPick = () => {
              try { txt.value = String(pick.value ?? '').trim(); } catch (_) {}
            };
            const syncFromTxt = () => {
              try {
                const v = String(txt.value ?? '').trim();
                if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v)) pick.value = v;
              } catch (_) {}
            };
            pick.addEventListener("input", syncFromPick);
            pick.addEventListener("change", syncFromPick);
            txt.addEventListener("input", syncFromTxt);
          }
        } catch (_) {}
      }
    });

    dlg.render(true);
  }

  async _onCategoryQuickAdd(btn) {
    const type = btn?.dataset?.type ?? this._activeTab;
    if (!TYPES.includes(type)) return;

    const name = await promptText({
      title: "New Category",
      label: "Category name",
      initial: ""
    });
    if (!name) return;

    const data = this._draftData ?? this._getSetting();
    const tab = data.tabs?.[type] ?? defaultShortcutsData().tabs[type];
    tab.categories = normalizeCategories(tab.categories);

    const id = foundry.utils.randomID();
    tab.categories.push({ id, name, icon: "fa-folder" });
    data.tabs[type] = tab;

    this._draftData = normalizeShortcutsData(data);
    this._activeCategoryByType[type] = id;
    this.render(false);
  }

  async _onOpenCategoryManager(btn) {
    const type = btn?.dataset?.type ?? this._activeTab;
    if (!TYPES.includes(type)) return;

    // Ensure latest form changes are captured before mutating categories
    this._syncDraftFromForm();

    const data = this._draftData ?? this._getSetting();
    const tab = data.tabs?.[type] ?? defaultShortcutsData().tabs[type];
    tab.categories = normalizeCategories(tab.categories);

    let selected = this._activeCategoryByType[type] ?? "all";
    if (selected !== "all" && !tab.categories.some(c => c.id === selected)) selected = "all";

    const renderContent = () => {
      const items = [
        `<div class="jsp-catmgr-item ${selected === "all" ? "active" : ""}" data-cat="all" title="All shortcuts"><i class="fas fa-th-large"></i><span>All</span></div>`,
        ...tab.categories.map(c => {
          const icon = cleanIcon(c.icon) || "fa-folder";
          const isImg = isImageIcon(icon);
          const iconHtml = isImg
            ? `<img src="${foundry.utils.escapeHTML(icon)}" alt="" />`
            : `<i class="fas ${foundry.utils.escapeHTML(icon)}"></i>`;
          return `<div class="jsp-catmgr-item ${selected === c.id ? "active" : ""}" data-cat="${foundry.utils.escapeHTML(c.id)}" title="${foundry.utils.escapeHTML(c.name)}">${iconHtml}<span>${foundry.utils.escapeHTML(c.name)}</span></div>`;
        })
      ].join("");

      return `
        <div class="jsp-catmgr" data-type="${foundry.utils.escapeHTML(type)}">
          <div class="jsp-catmgr-list">${items}</div>
          <p class="notes">Uncategorized shortcuts appear only under <b>All</b>.</p>
          <div class="jsp-catmgr-actions">
            <button type="button" class="jsp-btn compact" data-catmgr-action="add"><i class="fas fa-plus"></i> Add Category</button>
            <button type="button" class="jsp-btn compact" data-catmgr-action="rename"><i class="fas fa-i-cursor"></i> Rename</button>
            <button type="button" class="jsp-btn compact" data-catmgr-action="icon"><i class="fas fa-image"></i> Icon</button>
            <button type="button" class="jsp-btn compact" data-catmgr-action="delete"><i class="fas fa-trash"></i> Delete</button>
          </div>
        </div>
      `;
    };

    const dlg = new Dialog({
      title: `Manage Categories — ${TYPE_META[type]?.label ?? type}`,
      content: renderContent(),
      buttons: {
        close: { icon: "<i class='fas fa-times'></i>", label: "Close" }
      },
      render: (html) => {
        const root = html[0]?.querySelector(".jsp-catmgr");
        if (!root) return;

        // Selection
        root.querySelectorAll(".jsp-catmgr-item").forEach(el => {
          el.addEventListener("click", () => {
            selected = el.dataset.cat ?? "all";
            root.querySelectorAll(".jsp-catmgr-item").forEach(x => x.classList.toggle("active", x === el));
            this._activeCategoryByType[type] = selected;
          });
        });

        const runAndClose = async (fn) => {
          try { await fn(); } finally { dlg.close(); }
        };

        // Actions
        root.querySelector("[data-catmgr-action='add']")?.addEventListener("click", () => runAndClose(async () => {
          const name = await promptText({ title: "New Category", label: "Category name", initial: "" });
          if (!name) return;

          const id = foundry.utils.randomID();
          tab.categories.push({ id, name, icon: "fa-folder" });
          data.tabs[type] = tab;
          this._draftData = normalizeShortcutsData(data);
          this._activeCategoryByType[type] = id;
          this.render(false);
        }));

        root.querySelector("[data-catmgr-action='rename']")?.addEventListener("click", () => runAndClose(async () => {
          if (!selected || selected === "all") return ui.notifications?.warn("Select a category first.");

          const cat = tab.categories.find(c => c.id === selected);
          if (!cat) return;

          const name = await promptText({ title: "Rename Category", label: "Category name", initial: cat.name });
          if (!name) return;

          cat.name = name;
          data.tabs[type] = tab;
          this._draftData = normalizeShortcutsData(data);
          this.render(false);
        }));

        root.querySelector("[data-catmgr-action='icon']")?.addEventListener("click", () => runAndClose(async () => {
          if (!selected || selected === "all") return ui.notifications?.warn("Select a category first.");

          const cat = tab.categories.find(c => c.id === selected);
          if (!cat) return;

          const v = await promptText({ title: "Category Icon", label: "Enter a Font Awesome class (fa-*) or an image path", initial: cat.icon });
          if (v == null) return;

          cat.icon = cleanIcon(v);
          data.tabs[type] = tab;
          this._draftData = normalizeShortcutsData(data);
          this.render(false);
        }));

        root.querySelector("[data-catmgr-action='delete']")?.addEventListener("click", () => runAndClose(async () => {
          if (!selected || selected === "all") return ui.notifications?.warn("Select a category to delete.");

          const ok = await confirmDialog({
            title: "Delete Category",
            content: `<p>Delete this category? Shortcuts in it will become <b>uncategorized</b> (they will still appear under <b>All</b>).</p>`,
            yes: "Delete",
            no: "Cancel"
          });
          if (!ok) return;

          tab.categories = tab.categories.filter(c => c.id !== selected);
          tab.entries = toIndexArray(tab.entries).map(e => {
            const cid = String(e?.categoryId ?? "").trim();
            if (cid === selected) return { ...e, categoryId: "" };
            return e;
          });

          data.tabs[type] = tab;
          this._draftData = normalizeShortcutsData(data);
          this._activeCategoryByType[type] = "all";
          this.render(false);
        }));
      }
    });

    dlg.render(true);
  }


  async _updateObject(event, formData) {
    const expanded = foundry.utils.expandObject(formData);
    const data = normalizeShortcutsData(expanded.shortcuts);

    // Clean per-type: remove totally empty rows and trim
    for (const t of TYPES) {
      const tab = data.tabs[t];
      const cats = normalizeCategories(tab.categories);
      const validCatIds = new Set(cats.map(c => c.id));

      let cleaned = (tab.entries ?? [])
        .map(s => ({
          label: String(s?.label ?? "").trim(),
          uuid: String(s?.uuid ?? "").trim(),
          icon: cleanIcon(s?.icon ?? ""),
          visibleToPlayers: coerceBool(s?.visibleToPlayers, true),
          categoryId: String(s?.categoryId ?? "").trim(),
          entryType: (String(s?.entryType ?? "shortcut").trim().toLowerCase() === "divider") ? "divider" : "shortcut",
          dividerColor: String(s?.dividerColor ?? "").trim()
        }))
        // Keep rows that have a label (dividers always have labels) or a target uuid
        .filter(s => s.label || s.uuid);

      // If a GM drops a document but leaves label blank, auto-fill the label from the document name.
      for (const s of cleaned) {
        // Only auto-fill for real shortcuts (dividers are free text labels)
        if (s.entryType !== "divider" && !s.label && s.uuid) s.label = (await resolveName(s.uuid)) || "Shortcut";

        // Dividers are non-clickable; they should never retain a uuid target
        if (s.entryType === "divider") s.uuid = "";

        // Ensure divider color has a value when divider is selected
        if (s.entryType === "divider") {
          s.dividerColor = s.dividerColor || "#a855f7";
        } else {
          // For normal shortcuts, dividerColor is irrelevant but we keep it for future toggles
          s.dividerColor = s.dividerColor || "#a855f7";
        }

        if (s.categoryId === "default" || s.categoryId?.toLowerCase?.() === "default") s.categoryId = "";
        if (s.categoryId && !validCatIds.has(s.categoryId)) s.categoryId = "";
      }

      tab.icon = cleanIcon(tab.icon ?? TYPE_META[t]?.icon ?? "") || (TYPE_META[t]?.icon ?? "fa-link");
      tab.categories = cats;
      tab.entries = cleaned;
    }

    await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, data);
    this._draftData = null;

    ShortcutsOverlayPanel.instance?.refreshAll();
    ui.notifications?.info("Shortcuts saved.");
    this.render(false);
  }
}


/* -------------------------------------------- */
/* Init / Ready                                 */
/* -------------------------------------------- */

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, SETTING_SHORTCUTS, {
    name: "Shortcuts",
    hint: "Stored shortcuts for the overlay panel.",
    scope: "world",
    config: false,
    type: Object,
    onChange: () => {
      // Ensure all clients refresh the overlay immediately after the GM saves.
      ShortcutsOverlayPanel.instance?.refreshAll();
    },
    default: defaultShortcutsData()
  });

  game.settings.register(MODULE_ID, SETTING_ACTIVE_TYPE, {
    name: "Active Shortcut Category",
    hint: "Stores the last selected category for the overlay panel.",
    scope: "client",
    config: false,
    type: String,
    default: "actors"
  });



  game.settings.register(MODULE_ID, SETTING_ACTIVE_CATS, {
    name: "Active Shortcut Subcategory",
    hint: "Stores the last selected subcategory per shortcut type for the overlay panel.",
    scope: "client",
    config: false,
    type: Object,
    default: {}
  });

  game.settings.register(MODULE_ID, SETTING_PANEL_VISIBLE, {
    name: "Shortcuts Panel Visible",
    hint: "Stores whether the shortcuts overlay panel is currently shown.",
    scope: "client",
    config: false,
    type: Boolean,
    default: false,
    onChange: (visible) => {
      // Keep the overlay and token control button in sync.
      try {
        ShortcutsOverlayPanel.instance?.setVisible(visible);
        ui.controls?.render?.();
      } catch (_) {}
    }
  });

  game.keybindings.register(MODULE_ID, "togglePanel", {
    name: "Toggle ChristheDM's Shortcut Panel",
    hint: "Show or hide ChristheDM's Shortcut Panel.",
    editable: [{ key: "KeyY" }],
    onDown: () => {
      const cur = !!game.settings.get(MODULE_ID, SETTING_PANEL_VISIBLE);
      game.settings.set(MODULE_ID, SETTING_PANEL_VISIBLE, !cur);
      return true;
    }
  });

});

/* -------------------------------------------- */
/* Token Control Button                         */
/* -------------------------------------------- */

Hooks.on("dropCanvasData", async (canvasRef, data) => {
  try {
    if (!game.user.isGM) return;
    if (data?.jspSource !== MODULE_ID) return;
    if (data?.type !== "Item" || !data?.jspCreateTile || !data?.uuid) return;

    const item = await fromUuid(String(data.uuid));
    if (!item) return ui.notifications?.warn("That item could not be found anymore.");
    const scene = canvasRef?.scene ?? canvas.scene;
    if (!scene) return;

    const src = item.img || item.texture?.src || "icons/svg/item-bag.svg";
    const gridSize = Number(canvasRef?.dimensions?.size ?? canvas?.dimensions?.size ?? 100) || 100;
    let width = gridSize;
    let height = gridSize;

    try {
      const texture = await loadTexture(src);
      const tw = Number(texture?.width || texture?.baseTexture?.width || 0);
      const th = Number(texture?.height || texture?.baseTexture?.height || 0);
      if (tw > 0 && th > 0) {
        const ratio = tw / th;
        if (ratio >= 1) {
          width = gridSize;
          height = Math.max(32, Math.round(gridSize / ratio));
        } else {
          height = gridSize;
          width = Math.max(32, Math.round(gridSize * ratio));
        }
      }
    } catch (_) {}

    await scene.createEmbeddedDocuments("Tile", [{
      x: Math.round((Number(data.x) || 0) - (width / 2)),
      y: Math.round((Number(data.y) || 0) - (height / 2)),
      width,
      height,
      texture: { src }
    }]);
  } catch (err) {
    console.error(`${MODULE_ID} | Failed to create dropped item tile`, err);
    ui.notifications?.warn("Could not place that item on the scene.");
  }
});

Hooks.on("getSceneControlButtons", (controls) => {
  try {
    const toolName = "shortcutsPanelToggle";

    // v13+ may provide an object map (controls.tokens), older patterns can be an array.
    const tokenControls = Array.isArray(controls)
      ? controls.find(c => c?.name === "tokens")
      : controls?.tokens;

    if (!tokenControls) return;
    if (!tokenControls.tools) return;

    const applyToggle = (toggled) => {
      try {
        game.settings.set(MODULE_ID, SETTING_PANEL_VISIBLE, !!toggled);
      } catch (err) {
        console.error(err);
      }
    };

    // Tools can be a keyed object or an array depending on core/modules.
    if (Array.isArray(tokenControls.tools)) {
      if (tokenControls.tools.some(t => t?.name === toolName)) return;
      tokenControls.tools.push({
        name: toolName,
        title: "ChristheDM's Shortcut Panel",
        icon: "fas fa-book-open",
        toggle: true,
        active: !!game.settings.get(MODULE_ID, SETTING_PANEL_VISIBLE),
        visible: true,
        onClick: applyToggle,
        onChange: applyToggle
      });
    } else {
      if (tokenControls.tools[toolName]) return;
      tokenControls.tools[toolName] = {
        name: toolName,
        title: "ChristheDM's Shortcut Panel",
        icon: "fas fa-book-open",
        toggle: true,
        active: !!game.settings.get(MODULE_ID, SETTING_PANEL_VISIBLE),
        visible: true,
        onClick: applyToggle,
        onChange: applyToggle
      };
    }
  } catch (err) {
    console.error("JSP | Failed to add token control button:", err);
  }
});

Hooks.once("ready", async () => {
  // Migration: normalize legacy settings into the vNext data model (categories / visibility / icons).
  const raw = game.settings.get(MODULE_ID, SETTING_SHORTCUTS);
  if (game.user.isGM) {
    const needs = !(raw && typeof raw === "object" && raw.tabs && typeof raw.tabs === "object");
    if (needs) {
      await game.settings.set(MODULE_ID, SETTING_SHORTCUTS, normalizeShortcutsData(deepClone(raw)));
    }
  }

  ShortcutsOverlayPanel.instance = new ShortcutsOverlayPanel();
  // Restore the last visible state for this client.
  try {
    const visible = !!game.settings.get(MODULE_ID, SETTING_PANEL_VISIBLE);
    ShortcutsOverlayPanel.instance.setVisible(visible);
  } catch (_) {}
});
